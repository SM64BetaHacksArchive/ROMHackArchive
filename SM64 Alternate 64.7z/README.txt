No bonus rom again, sorry.
Thanks to theswguy for the rom.
- SM64 Beta Hacks Archive