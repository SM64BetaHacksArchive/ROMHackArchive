Neat, this version of the hack is unseen.
Thanks to UltraLuigi240 for this rom.
- SM64 Beta Hacks Archive