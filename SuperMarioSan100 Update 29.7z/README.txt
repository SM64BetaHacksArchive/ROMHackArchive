Yes, the Master M build without Master M.
Thanks to UltraLuigi2401 for the rom!
- SM64 Beta Hacks Archive