fun fact: This wasn't even recorded once. There's no footage of this except my afaik.
No bonus rom again, sorry.
ROM in vid: 10.bps
thanks to ultraluigi2401 for those
- SM64 Beta Hacks Archive