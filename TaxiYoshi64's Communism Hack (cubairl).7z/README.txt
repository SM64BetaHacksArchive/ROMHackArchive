No bonus rom again, i'm terribly sorry.
- SM64 Beta Hacks Archive