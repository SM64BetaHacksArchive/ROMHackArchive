I added an bonus rom this time.
Also this hack may be not Dustin's.
- SM64 Beta Hacks Archive