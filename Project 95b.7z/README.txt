YES, THIS IS NOT A TYPO.
This is real 95b, with the famous Mero Land™ preserved (considering a small leaker in my server who posts very specific pictures that have leaks encoded in edits the roms (If a rom was edited before leak, that's NOT preservation)).
Thanks to CiaranKellyYTNumber2 on discord for the rom.
- SM64 Beta Hacks archive 