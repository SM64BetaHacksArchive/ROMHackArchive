This version is newer than the one that got leaked by Beta Walker.
Thanks RealGrude for this rom.
- SM64 Beta Hacks Archive