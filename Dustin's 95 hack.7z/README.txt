no bonus rom again, sorry
also this reminds me of U64DA for some reason?
- SM64 Beta Hacks Archive