This is a lost early build of the hack, i doubt the newer one is made by real Dustin.
Thanks to AmitabhTechz for the rom.
- SM64 Beta Hacks Archive