thanks to AmitabhTechz for this rom.
Also, no bonus rom again, sorry.
- SM64 Beta Hacks Archive