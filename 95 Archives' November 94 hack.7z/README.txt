there's no bonus rom again, sorry.
- SM64 Beta Hacks Archive