No bonus rom again, sorry.
- SM64 Beta Hacks Archive